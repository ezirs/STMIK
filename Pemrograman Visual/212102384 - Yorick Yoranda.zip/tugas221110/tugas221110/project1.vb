﻿Public Class frm_helloWorld

    Private Sub btn_Click_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Click.Click
        MessageBox.Show("Hello world! Ini Visual Basic .NET")
    End Sub
End Class