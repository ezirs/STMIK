﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Tugas221110ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProjectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LainnyaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project11ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeluarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project16ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project17ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Project18ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tugas221110ToolStripMenuItem, Me.KeluarToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(422, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Tugas221110ToolStripMenuItem
        '
        Me.Tugas221110ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProjectsToolStripMenuItem})
        Me.Tugas221110ToolStripMenuItem.Name = "Tugas221110ToolStripMenuItem"
        Me.Tugas221110ToolStripMenuItem.Size = New System.Drawing.Size(89, 20)
        Me.Tugas221110ToolStripMenuItem.Text = "Tugas 221110"
        '
        'ProjectsToolStripMenuItem
        '
        Me.ProjectsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LainnyaToolStripMenuItem, Me.Project1ToolStripMenuItem, Me.Project2ToolStripMenuItem, Me.Project3ToolStripMenuItem, Me.Project4ToolStripMenuItem, Me.Project5ToolStripMenuItem, Me.Project6ToolStripMenuItem, Me.Project7ToolStripMenuItem, Me.Project8ToolStripMenuItem, Me.Project9ToolStripMenuItem, Me.Project10ToolStripMenuItem})
        Me.ProjectsToolStripMenuItem.Name = "ProjectsToolStripMenuItem"
        Me.ProjectsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ProjectsToolStripMenuItem.Text = "Projects"
        '
        'LainnyaToolStripMenuItem
        '
        Me.LainnyaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Project11ToolStripMenuItem, Me.Project16ToolStripMenuItem, Me.Project17ToolStripMenuItem, Me.Project18ToolStripMenuItem})
        Me.LainnyaToolStripMenuItem.Name = "LainnyaToolStripMenuItem"
        Me.LainnyaToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LainnyaToolStripMenuItem.Text = "Lainnya"
        '
        'Project11ToolStripMenuItem
        '
        Me.Project11ToolStripMenuItem.Name = "Project11ToolStripMenuItem"
        Me.Project11ToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.Project11ToolStripMenuItem.Text = "Project 11,12, 13, 14, 15"
        '
        'Project1ToolStripMenuItem
        '
        Me.Project1ToolStripMenuItem.Name = "Project1ToolStripMenuItem"
        Me.Project1ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project1ToolStripMenuItem.Text = "Project 1"
        '
        'Project2ToolStripMenuItem
        '
        Me.Project2ToolStripMenuItem.Name = "Project2ToolStripMenuItem"
        Me.Project2ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project2ToolStripMenuItem.Text = "Project 2"
        '
        'Project3ToolStripMenuItem
        '
        Me.Project3ToolStripMenuItem.Name = "Project3ToolStripMenuItem"
        Me.Project3ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project3ToolStripMenuItem.Text = "Project 3"
        '
        'Project4ToolStripMenuItem
        '
        Me.Project4ToolStripMenuItem.Name = "Project4ToolStripMenuItem"
        Me.Project4ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project4ToolStripMenuItem.Text = "Project 4"
        '
        'Project5ToolStripMenuItem
        '
        Me.Project5ToolStripMenuItem.Name = "Project5ToolStripMenuItem"
        Me.Project5ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project5ToolStripMenuItem.Text = "Project 5"
        '
        'Project6ToolStripMenuItem
        '
        Me.Project6ToolStripMenuItem.Name = "Project6ToolStripMenuItem"
        Me.Project6ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project6ToolStripMenuItem.Text = "Project 6"
        '
        'Project7ToolStripMenuItem
        '
        Me.Project7ToolStripMenuItem.Name = "Project7ToolStripMenuItem"
        Me.Project7ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project7ToolStripMenuItem.Text = "Project 7"
        '
        'Project8ToolStripMenuItem
        '
        Me.Project8ToolStripMenuItem.Name = "Project8ToolStripMenuItem"
        Me.Project8ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project8ToolStripMenuItem.Text = "Project 8"
        '
        'Project9ToolStripMenuItem
        '
        Me.Project9ToolStripMenuItem.Name = "Project9ToolStripMenuItem"
        Me.Project9ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project9ToolStripMenuItem.Text = "Project 9"
        '
        'Project10ToolStripMenuItem
        '
        Me.Project10ToolStripMenuItem.Name = "Project10ToolStripMenuItem"
        Me.Project10ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.Project10ToolStripMenuItem.Text = "Project 10"
        '
        'KeluarToolStripMenuItem
        '
        Me.KeluarToolStripMenuItem.Name = "KeluarToolStripMenuItem"
        Me.KeluarToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.KeluarToolStripMenuItem.Text = "Keluar"
        '
        'Project16ToolStripMenuItem
        '
        Me.Project16ToolStripMenuItem.Name = "Project16ToolStripMenuItem"
        Me.Project16ToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.Project16ToolStripMenuItem.Text = "Project 16"
        '
        'Project17ToolStripMenuItem
        '
        Me.Project17ToolStripMenuItem.Name = "Project17ToolStripMenuItem"
        Me.Project17ToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.Project17ToolStripMenuItem.Text = "Project 17"
        '
        'Project18ToolStripMenuItem
        '
        Me.Project18ToolStripMenuItem.Name = "Project18ToolStripMenuItem"
        Me.Project18ToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.Project18ToolStripMenuItem.Text = "Project 18"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(422, 261)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Tugas221110ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjectsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeluarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LainnyaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project11ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project7ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project8ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project9ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project10ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project16ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project17ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Project18ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
