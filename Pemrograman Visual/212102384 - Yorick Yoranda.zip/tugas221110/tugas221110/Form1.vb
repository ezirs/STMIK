﻿Public Class Form1

    Private Sub Project1ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project1ToolStripMenuItem.Click
        frm_helloWorld.Show()
    End Sub

    Private Sub KeluarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeluarToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub Project2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project2ToolStripMenuItem.Click
        frm_labelDanTextBox.Show()
    End Sub

    Private Sub Project3ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project3ToolStripMenuItem.Click
        frm_groupBoxDanRadioButtot.Show()
    End Sub

    Private Sub Project4ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project4ToolStripMenuItem.Click
        frm_checkBox.Show()
    End Sub

    Private Sub Project5ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project5ToolStripMenuItem.Click
        frm_comboBoxDanListBox.Show()
    End Sub

    Private Sub Project6ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project6ToolStripMenuItem.Click
        frm_dateTimePicker.Show()
    End Sub

    Private Sub Project7ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project7ToolStripMenuItem.Click
        frm_webBrowser.Show()
    End Sub

    Private Sub Project8ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project8ToolStripMenuItem.Click
        frm_panelDanNumericUpDown.Show()
    End Sub

    Private Sub Project9ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project9ToolStripMenuItem.Click
        frm_notifyIcon.Show()
    End Sub

    Private Sub Project10ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project10ToolStripMenuItem.Click
        frm_anchor.Show()
    End Sub

    Private Sub Project11ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project11ToolStripMenuItem.Click
        frm_notepadSederhana.Show()
    End Sub

    Private Sub Project16ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project16ToolStripMenuItem.Click
        frm_tapConrol.Show()
    End Sub

    Private Sub Project17ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project17ToolStripMenuItem.Click
        frm_multipleForm.Show()
    End Sub

    Private Sub Project18ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Project18ToolStripMenuItem.Click
        frm_parent.Show()
    End Sub
End Class
